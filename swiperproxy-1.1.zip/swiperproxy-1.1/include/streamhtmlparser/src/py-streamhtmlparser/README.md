py-streamhtmlparser
===================

py-streamhtmlparser is a Cython-based wrapper for the streamhtmlparser
library.

License
-------

py-streamhtmlparser is licensed under the MIT license. See the
`COPYING.md` file in `/doc/`.

Download
--------

See <https://swiperproxy.github.io/py-streamhtmlparser.html> for
releases, git checkout instructions and documentation.

Create a clone of this repository
---------------------------------

Clone the repo by running:
`$ git clone https://github.com/SwiperProxy/py-streamhtmlparser.git`

Support
-------

Commercial installation and support is not available. For general
community support, see <https://swiperproxy.github.io/contact.html>.
